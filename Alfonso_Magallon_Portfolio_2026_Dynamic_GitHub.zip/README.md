# Alfonso Magallón — Portfolio 2026 · Dynamic

Versión dinámica, editorial y totalmente responsive para GitHub Pages.

### Incluye
- Carrusel automático por proyecto: las series de imágenes de cada proyecto se convierten en una galería independiente.
- Flechas, contador, barra de progreso y miniaturas.
- Swipe táctil en celular.
- Lightbox para ampliar las obras.
- Navegación por teclado.
- Videos con `autoplay`, `loop`, `muted` y `playsinline`.
- Los videos se pausan cuando salen de la diapositiva activa.
- Scroll reveal, barra de progreso global y navegación activa.
- Menú hamburguesa animado a X.
- Hover avanzado y estados `:active`.
- Responsive para PC, tablet y celular.
- Respeto de la proporción original de las imágenes: no se fuerzan recortes de las obras.
- Soporte para `prefers-reduced-motion`.

### Archivos
`index.html`, `style.css`, `script.js` y esta guía.

La carpeta `images/` **no está incluida** para evitar duplicar los archivos de obra. Usa la misma carpeta `images/` del portfolio original, con los archivos `1.png` a `72.jpg/mp4` en las rutas indicadas.

### GitHub Pages
1. Copia los tres archivos principales y tu carpeta `images/` a la raíz del repositorio.
2. Haz commit y push.
3. GitHub → **Settings → Pages**.
4. Selecciona **Deploy from a branch**, rama `main`, carpeta `/ (root)`.
5. Guarda y espera la publicación.

GitHub Pages distingue mayúsculas/minúsculas en las rutas. Mantén los nombres de los archivos exactamente como aparecen en el proyecto.
